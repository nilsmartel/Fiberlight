
public class PixelShader{
  static Pixel ambient( RenderData pass ){
    int grey = 64 + (int)(128*pass.fresnel);
    return new Pixel(grey,grey,grey);
  }

  static Pixel reflection( RenderData pass ){
    Pixel refl = TextureStack.polar.getChoordPixel( (0.5+pass.nrm_x/2)%1, 0.5+pass.nrm_y/2 );
    Pixel color= new Pixel( 48, 230, 64);
    return color.blend(refl, 0.02+ 1-(pass.fresnel*0.98) );
  }
}
