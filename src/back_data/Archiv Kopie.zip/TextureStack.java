
public class TextureStack{
  public static Idx polar;
  public static void loadTextureMaps(){
    TextureStack.polar = new Idx("map/beach.jpg");
  }
}
